"""MiniMax H3 single-frame image nodes.

H3 normally runs on the 17k+5 video-frame grid, but it can also denoise a single
latent frame which is how its own image previews work. H3 Image Latent builds
that latent; H3 Image Decode turns it back into an image.

Use it in place of the latent from "MiniMax H3 Image to Video" (keep that node
for its conditioning) and in place of VAE Decode.
"""
import torch

import comfy.model_management
import comfy.nested_tensor

FPS = 24
AUDIO_LATENT_FPS = 40
AUDIO_T = round(AUDIO_LATENT_FPS / FPS)  # audio latents that pair with one video frame


class H3ImageLatent:
    """Empty single-frame MiniMax H3 latent (video + audio)."""

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "width": ("INT", {"default": 1024, "min": 64, "max": 4096, "step": 32}),
            "height": ("INT", {"default": 1024, "min": 64, "max": 4096, "step": 32}),
            "batch_size": ("INT", {"default": 1, "min": 1, "max": 64}),
        }}

    RETURN_TYPES = ("LATENT",)
    FUNCTION = "make"
    CATEGORY = "MiniMax H3"

    def make(self, width, height, batch_size):
        device = comfy.model_management.intermediate_device()
        # 16 px per latent pixel; the DiT patchifies 2x2, so the latent must be even
        latent_w = (width // 16) // 2 * 2
        latent_h = (height // 16) // 2 * 2
        video = torch.zeros((batch_size, 24, 1, latent_h, latent_w), device=device)
        audio = torch.zeros((batch_size, 32, 2, AUDIO_T), device=device)
        return ({"samples": comfy.nested_tensor.NestedTensor((video, audio))},)


class H3ImageDecode:
    """VAE Decode that accepts the nested latent above."""

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"samples": ("LATENT",), "vae": ("VAE",)}}

    RETURN_TYPES = ("IMAGE",)
    FUNCTION = "decode"
    CATEGORY = "MiniMax H3"

    def decode(self, vae, samples):
        latent = samples["samples"]
        if latent.is_nested:
            latent = latent.unbind()[0]
        images = vae.decode(latent)
        if images.ndim == 5:  # merge batch and frames
            images = images.flatten(0, 1)
        return (images,)


MAX_WAIT = 16


class H3WaitForConditioning:
    """Pass a latent through only once every linked conditioning exists.

    ComfyUI walks the graph depth-first, so several encode -> sample chains run
    one after another and the text encoder and diffusion model evict each other
    on every chain. Feeding each sampler's latent through this node makes all of
    the encodes run first, on one load of the text encoder, and all of the
    sampling after, on one load of the diffusion model.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {"samples": ("LATENT",)},
            "optional": {f"conditioning_{i}": ("CONDITIONING",) for i in range(MAX_WAIT)},
        }

    RETURN_TYPES = ("LATENT",)
    FUNCTION = "wait"
    CATEGORY = "MiniMax H3"

    def wait(self, samples, **conditioning):
        return (samples,)


NODE_CLASS_MAPPINGS = {
    "H3ImageLatent": H3ImageLatent,
    "H3ImageDecode": H3ImageDecode,
    "H3WaitForConditioning": H3WaitForConditioning,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "H3ImageLatent": "H3 Image Latent",
    "H3ImageDecode": "H3 Image Decode",
    "H3WaitForConditioning": "H3 Wait For Conditioning",
}
