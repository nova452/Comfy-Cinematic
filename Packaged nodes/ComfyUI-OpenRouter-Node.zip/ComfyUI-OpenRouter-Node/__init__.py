import json
import os
import time
import threading
import wave
import requests
import base64
import io
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from PIL import Image
import torch

# Optional ComfyUI integration: lets the node abort an in-flight API request
# as soon as the user cancels the queue (Interrupt button). When this module
# is imported outside ComfyUI the import fails and cancellation is disabled.
try:
    from comfy import model_management as _model_management
except Exception:
    _model_management = None

# The default system prompt from the original script
DEFAULT_SYSTEM_PROMPT = """"""

# The default JSON Schema extracted from promptJsonFormat
DEFAULT_SCHEMA = {
  "type": "object",
  "properties": {
    "aspect_ratio": { "type": "string", "description": "Aspect ratio in width:height format, e.g. '1648:1296'." },
    "high_level_description": { "type": "string", "description": "A concise high-level description of the image, capturing the subject, pose, and key visual elements." },
    "style_description": {
      "type": "object",
      "properties": {
        "aesthetics": { "type": "string", "description": "Description of the visual aesthetics, such as lighting, reflections, and surface qualities." },
        "photo": { "type": "string", "description": "Description of the image quality and production characteristics." },
        "art_style": { "type": "string", "description": "Tags and descriptors for the art style, including genre references and influences." },
        "medium": { "type": "string", "description": "The medium or format of the artwork, e.g. 'Official Art digital media'." },
        "color_palette": { "type": "array", "items": { "type": "string", "pattern": "^#[0-9A-Fa-f]{6}$" }, "description": "Array of hex color codes representing the dominant color palette." }
      },
      "required": ["aesthetics", "photo", "art_style", "medium", "color_palette"],
      "additionalProperties": False
    },
    "compositional_deconstruction": {
      "type": "object",
      "properties": {
        "background": { "type": "string", "description": "Detailed description of the background environment, architecture, lighting, and atmosphere." },
        "elements": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "type": { "type": "string", "description": "The type of element, e.g. 'obj'." },
              "bbox": { "type": "array", "items": { "type": "number" }, "minItems": 4, "maxItems": 4, "description": "Bounding box as [x1, y1, x2, y2] pixel coordinates." },
              "desc": { "type": "string", "description": "Short description of the element." },
              "color_palette": { "type": "array", "items": { "type": "string", "pattern": "^#[0-9A-Fa-f]{6}$" }, "description": "Array of hex color codes associated with this element." }
            },
            "required": ["type", "bbox", "desc", "color_palette"],
            "additionalProperties": False
          },
          "description": "Array of compositional elements with bounding boxes and descriptions."
        }
      },
      "required": ["background", "elements"],
      "additionalProperties": False
    }
  },
  "required": ["aspect_ratio", "high_level_description", "style_description", "compositional_deconstruction"],
  "additionalProperties": False
}

# Valid quantization values accepted by OpenRouter's provider routing.
VALID_QUANTIZATIONS = {"int4", "int8", "fp4", "fp6", "fp8", "fp16", "bf16", "fp32", "unknown"}

# Networking tuning.
#
# The request is streamed (see `stream: True` in the payload) so the read
# timeout applies to the gap between individual chunks rather than to the
# entire generation. A long-but-healthy response therefore never trips the
# timeout, while a genuinely stalled connection fails fast instead of hanging
# for the full duration.
#
# CONNECT_TIMEOUT: max seconds to establish the TCP/TLS connection.
# READ_TIMEOUT:    max seconds to wait for the next chunk of data.
# MAX_RETRIES:     how many times to retry a stalled/failed request.
# RETRY_BACKOFF:   base seconds for exponential backoff between retries.
CONNECT_TIMEOUT = 15
READ_TIMEOUT = 60
MAX_RETRIES = 2
RETRY_BACKOFF = 2.0


def parse_model_slug(model):
    """Split a model slug that may carry a /provider/quantization suffix.

    OpenRouter model slugs are only `author/model`, but users often write
    e.g. `deepseek/deepseek-v4.1-flash/venice/fp8`. The extra segments are
    not slug syntax (the API rejects them with a 400), so they are parsed
    out here and translated into a `provider` routing object instead:

        author/model[/provider][/quantization]

    Returns (clean_model, provider_dict_or_None).
    """
    parts = model.split("/")
    clean = "/".join(parts[:2])
    provider = None

    if len(parts) > 2 and parts[2]:
        provider = {"only": [parts[2]], "allow_fallbacks": False}
        if len(parts) > 3 and parts[3]:
            quant = parts[3].lower()
            if quant in VALID_QUANTIZATIONS:
                provider["quantizations"] = [quant]
    return clean, provider


# OpenRouter accepts video content parts as `video_url` entries whose url is
# either a public URL or a base64 data URL. These are the container types
# OpenRouter documents as supported (see "Video Inputs").
VIDEO_MIME_BY_EXTENSION = {
    ".mp4": "video/mp4",
    ".m4v": "video/mp4",
    ".mov": "video/mov",
    ".webm": "video/webm",
    ".mpg": "video/mpeg",
    ".mpeg": "video/mpeg",
}


def _sniff_video_mime(data):
    """Best-effort container detection from the first bytes of a video file."""
    if len(data) >= 12 and data[4:8] == b"ftyp":
        return "video/mov" if data[8:12] == b"qt  " else "video/mp4"
    if data[:4] == b"\x1a\x45\xdf\xa3":
        return "video/webm"
    if data[:4] in (b"\x00\x00\x01\xba", b"\x00\x00\x01\xb3"):
        return "video/mpeg"
    return None


def _video_to_data_uri(video):
    """Turn a ComfyUI VIDEO input into an OpenRouter base64 video data URL.

    Passing the original encoded bytes through (when the source is a file or
    an already-encoded stream) avoids a lossy and potentially expensive
    re-encode. Anything that cannot be identified is re-encoded to H.264 MP4,
    which every OpenRouter video-capable provider accepts.
    """
    # Nodes that emit lists (e.g. dataset loaders) hand us a list of videos;
    # send the first one rather than failing.
    if isinstance(video, (list, tuple)):
        video = next((item for item in video if item is not None), None)
        if video is None:
            return None

    data = None
    mime = None

    try:
        source = video.get_stream_source()
    except Exception:
        source = None

    if isinstance(source, str) and os.path.isfile(source):
        mime = VIDEO_MIME_BY_EXTENSION.get(os.path.splitext(source)[1].lower())
        if mime is not None:
            with open(source, "rb") as handle:
                data = handle.read()
    elif hasattr(source, "read"):
        try:
            raw = source.read()
        except Exception:
            raw = None
        if raw:
            mime = _sniff_video_mime(raw)
            if mime is not None:
                data = raw

    if data is None:
        buffer = io.BytesIO()
        video.save_to(buffer, format="mp4")
        data = buffer.getvalue()
        mime = "video/mp4"

    encoded = base64.b64encode(data).decode("utf-8")
    return f"data:{mime};base64,{encoded}"


def _image_content_parts(image):
    """ComfyUI IMAGE tensor [B, H, W, C] -> one image_url part per image."""
    parts = []
    batch_np = np.clip(255. * image.cpu().numpy(), 0, 255).astype(np.uint8)
    for batch_img in batch_np:
        buffered = io.BytesIO()
        Image.fromarray(batch_img).save(buffered, format="JPEG", quality=90)
        img_b64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
        parts.append({
            "type": "image_url",
            "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}
        })
    return parts


def _audio_content_part(audio):
    """ComfyUI AUDIO input -> OpenRouter `input_audio` part (16-bit PCM WAV)."""
    if isinstance(audio, (list, tuple)):
        audio = next((item for item in audio if item is not None), None)
        if audio is None:
            return None

    waveform = audio["waveform"]
    sample_rate = int(audio["sample_rate"])
    if waveform.ndim == 3:      # [B, C, L] -> first item
        waveform = waveform[0]
    if waveform.ndim == 1:      # [L] -> mono [1, L]
        waveform = waveform.unsqueeze(0)

    # [C, L] float in [-1, 1] -> interleaved [L, C] 16-bit PCM
    samples = waveform.cpu().float().clamp(-1.0, 1.0).movedim(0, -1).numpy()
    pcm = (samples * 32767.0).astype(np.int16)

    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as handle:
        handle.setnchannels(pcm.shape[1])
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        handle.writeframes(pcm.tobytes())

    return {
        "type": "input_audio",
        "input_audio": {
            "data": base64.b64encode(buffer.getvalue()).decode("utf-8"),
            "format": "wav",
        },
    }


def _format_decision_answer(question_id, answer):
    """One readable `question_id: value` line for any Decisions answer shape."""
    if not isinstance(answer, dict):
        return f"{question_id}: {answer}"

    for key in ("choice", "noul", "score", "box"):
        if key in answer:
            value = answer[key]
            if key == "box":
                value = json.dumps(value, ensure_ascii=False)
            line = f"{question_id}: {value}"
            break
    else:
        line = f"{question_id}: {json.dumps(answer, ensure_ascii=False)}"

    confidence = answer.get("confidence")
    if confidence is not None:
        line += f" (confidence {confidence})"
    return line


def _noul_value(answer):
    """Read the 0..1 probability out of a noul answer.

    Accepts a raw answer ({"type": "noul", "noul": 0.86}), a bare number, a
    true/false choice, or a "true"/"false" string. Returns None when the
    answer carries no usable value.
    """
    if isinstance(answer, dict):
        answer = answer.get("noul", answer.get("choice", answer))

    if isinstance(answer, bool):
        return 1.0 if answer else 0.0
    if isinstance(answer, (int, float)):
        return float(answer)
    if isinstance(answer, str):
        text = answer.strip().lower()
        if text in ("true", "yes", "on"):
            return 1.0
        if text in ("false", "no", "off"):
            return 0.0
        try:
            return float(text)
        except ValueError:
            return None
    return None


def _answer_to_bool(answer, threshold):
    value = _noul_value(answer)
    return value is not None and value >= threshold


def _post_streaming(session, url, headers, payload):
    """POST a streaming chat completion and reassemble the full response.

    Streaming keeps the read timeout meaningful: it applies to the gap between
    chunks, not to the whole generation, so a slow-but-alive model won't trip
    it while a dead connection fails quickly. The streamed SSE chunks are
    merged back into a single OpenAI-style response dict so the rest of the
    node can consume it unchanged.
    """
    stream_payload = dict(payload)
    stream_payload["stream"] = True

    content_parts = []
    reasoning_parts = []
    finish_reason = None
    model_name = stream_payload.get("model")

    with session.post(
        url,
        headers=headers,
        json=stream_payload,
        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
        stream=True,
    ) as response:
        response.raise_for_status()
        # SSE responses do not declare a charset, so requests would decode
        # iter_lines(decode_unicode=True) as ISO-8859-1 and garble multi-byte
        # UTF-8 characters (em dashes, curly quotes, CJK, ...) into mojibake
        # like "worldâ". Force UTF-8, which is what the API actually sends.
        response.encoding = "utf-8"
        for line in response.iter_lines(decode_unicode=True):
            # Abort promptly if the user cancels mid-generation.
            _check_interrupted()
            if not line:
                continue
            if line.startswith("data:"):
                line = line[len("data:"):].strip()
            if not line or line == "[DONE]":
                continue
            try:
                chunk = json.loads(line)
            except json.JSONDecodeError:
                continue

            if chunk.get("model"):
                model_name = chunk["model"]
            for choice in chunk.get("choices", []):
                # Non-streaming fallback: some providers ignore `stream: True`
                # and return a regular completion body with a full `message`.
                message = choice.get("message")
                if message is not None:
                    if message.get("content"):
                        content_parts.append(message["content"])
                    reasoning_msg = message.get("reasoning") or message.get("reasoning_content")
                    if reasoning_msg:
                        reasoning_parts.append(reasoning_msg)
                    if choice.get("finish_reason"):
                        finish_reason = choice["finish_reason"]
                    continue

                delta = choice.get("delta") or {}
                if delta.get("content"):
                    content_parts.append(delta["content"])
                # Some providers stream reasoning under delta.reasoning or
                # delta.reasoning_content.
                reasoning_delta = delta.get("reasoning") or delta.get("reasoning_content")
                if reasoning_delta:
                    reasoning_parts.append(reasoning_delta)
                if choice.get("finish_reason"):
                    finish_reason = choice["finish_reason"]

    return {
        "model": model_name,
        "choices": [
            {
                "finish_reason": finish_reason,
                "message": {
                    "role": "assistant",
                    "content": "".join(content_parts),
                    "reasoning": "".join(reasoning_parts),
                },
            }
        ],
    }


def _check_interrupted():
    """Raise ComfyUI's InterruptProcessingException if the user cancelled.

    ComfyUI's executor treats that exception as a clean interruption
    ("execution_interrupted") rather than a node error, so the queue stops
    gracefully.
    """
    if _model_management is not None and _model_management.processing_interrupted():
        raise _model_management.InterruptProcessingException()


def _interruptible_sleep(seconds):
    """Sleep in short slices, aborting early if the user cancels."""
    end = time.monotonic() + seconds
    while True:
        _check_interrupted()
        remaining = end - time.monotonic()
        if remaining <= 0:
            break
        time.sleep(min(0.25, remaining))


def _post_streaming_with_cancel(session, url, headers, payload):
    """Run the streaming request in a worker thread and watch for cancellation.

    The blocking HTTP read happens on a worker thread while this thread polls
    ComfyUI's interrupt flag every 0.25s. If the user cancels, the session is
    force-closed, which immediately unblocks the stalled read, and ComfyUI's
    InterruptProcessingException is raised so the node stops cleanly instead
    of waiting for the request to finish or time out.
    """
    result = {}
    error = []

    def _worker():
        try:
            result["response"] = _post_streaming(session, url, headers, payload)
        except BaseException as e:  # noqa: BLE001 - re-raised on the caller thread
            error.append(e)

    thread = threading.Thread(target=_worker, daemon=True)
    thread.start()
    while thread.is_alive():
        thread.join(timeout=0.25)
        if _model_management is not None and _model_management.processing_interrupted():
            # Force-close the pooled connection so the blocked read in the
            # worker raises immediately instead of hanging until timeout.
            try:
                session.close()
            except Exception:
                pass
            raise _model_management.InterruptProcessingException()
    if error:
        raise error[0]
    return result["response"]


class OpenRouterStructuredOutput:
    def __init__(self):
        pass

    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                
                "system_prompt": ("STRING", {"default": DEFAULT_SYSTEM_PROMPT, "multiline": True}),
                "user_prompt": ("STRING", {"default": "", "multiline": True}),
                "api_key": ("STRING", {"default": "sk-or-v1-...", "multiline": False}),
                "model": ("STRING", {"default": "google/gemini-3-flash-preview"}),
                "temperature": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.01}),
                "top_p": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.01}),
                "frequency_penalty": ("FLOAT", {"default": 0.0, "min": -2.0, "max": 2.0, "step": 0.01}),
                "presence_penalty": ("FLOAT", {"default": 0.0, "min": -2.0, "max": 2.0, "step": 0.01}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff}),
                "reasoning_effort": (["none", "minimal", "low", "medium", "high", "xhigh"], {"default": "none"}),
                "service_tier": (["default", "flex", "priority"], {"default": "default"}),
            },
            "optional": {
                "image": ("IMAGE",),
                "video": ("VIDEO",),
                "json_schema": ("STRING", {"default": json.dumps(DEFAULT_SCHEMA, indent=2), "multiline": True}),
                "response_format": (["json_schema", "json_object"], {"default": "json_schema"}),
            }
        }
    
    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("raw_output", "processed_output", "reasoning")
    FUNCTION = "generate"
    CATEGORY = "API/OpenRouter"

    def generate(self, user_prompt, system_prompt, api_key, model, temperature, top_p, frequency_penalty, presence_penalty, seed, reasoning_effort, service_tier, image=None, video=None, json_schema=None, response_format="json_schema", extra_turns=None, assistant_prefill=None):
        if not api_key or api_key == "sk-or-v1-...":
            return ("Error: Valid API Key is required.", "")

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        # Build messages structure
        messages = [{"role": "system", "content": system_prompt}]

        # Insert optional prior conversation turns (assistant_1, user_2,
        # assistant_2, ... user_4) before the final user message.
        if extra_turns:
            for role, text in extra_turns:
                if text is None:
                    continue
                text = str(text).strip()
                if not text:
                    continue
                messages.append({"role": role, "content": text})

        if image is not None or video is not None:
            content = [{"type": "text", "text": user_prompt}]
            if image is not None:
                # Convert ComfyUI image tensor(s) to base64 strings. The tensor
                # shape is [B, H, W, C]; every image in the batch is sent as its
                # own image_url content part, so models with multi-image support
                # can see all of them.
                batch_np = np.clip(255. * image.cpu().numpy(), 0, 255).astype(np.uint8)
                for batch_img in batch_np:
                    img = Image.fromarray(batch_img)
                    buffered = io.BytesIO()
                    img.save(buffered, format="JPEG", quality=90)
                    img_b64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
                    content.append({
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}
                    })

            if video is not None:
                # Video-capable models (e.g. Gemini) accept a `video_url`
                # content part holding either a public URL or a base64 data
                # URL. The part is only added when a video is actually
                # connected, so image-only and text-only models keep working.
                try:
                    video_data_uri = _video_to_data_uri(video)
                except Exception as e:
                    return (f"Error: Unable to encode video input: {e}", "", "")
                if video_data_uri:
                    content.append({
                        "type": "video_url",
                        "video_url": {"url": video_data_uri}
                    })

            messages.append({"role": "user", "content": content})
        else:
            # Text only
            messages.append({
                "role": "user",
                "content": user_prompt
            })

        # Assistant prefill (OpenRouter API Reference > Assistant prefill):
        # include a message with role "assistant" at the END of the messages
        # array so the model continues from that partial response. It must be
        # the last message, i.e. come after the final user message.
        if assistant_prefill is not None:
            assistant_prefill = str(assistant_prefill)
            if assistant_prefill.strip():
                messages.append({"role": "assistant", "content": assistant_prefill})

        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "frequency_penalty": frequency_penalty,
            "presence_penalty": presence_penalty,
            # Some providers (e.g. Google Gemini via OpenRouter) require seed
            # to be a signed 32-bit int (TYPE_INT32, max 2147483647). ComfyUI
            # seed widgets can produce 64-bit values, so mask to 31 bits to
            # stay within the valid positive INT32 range.
            "seed": seed & 0x7FFFFFFF
        }

        # Support `author/model[/provider][/quantization]` model strings. The
        # suffix is stripped from the slug and converted into OpenRouter
        # provider routing so requests like
        # `deepseek/deepseek-v4.1-flash/venice/fp8` route to the requested
        # provider/quantization instead of failing slug validation with 400.
        model, provider_routing = parse_model_slug(model)
        if provider_routing:
            payload["model"] = model
            payload["provider"] = provider_routing

        # Add reasoning config.
        # Per OpenRouter docs (Reasoning Tokens), "effort": "none" disables
        # reasoning entirely, but only on models that list "none" as a
        # supported effort. Models that reason by default (e.g.
        # moonshotai/kimi-k3) and Gemini 3 models (whose thinkingLevel API has
        # no "off" level) ignore or reject effort "none" and keep thinking.
        # The reliable way to turn reasoning off is "enabled": false — that is
        # what OpenRouter maps Anthropic's thinking: {type: "disabled"} to —
        # so "none" is sent as {"enabled": false} instead.
        # Note: models marked "mandatory" in their reasoning metadata reject
        # disabling entirely — reasoning cannot be turned off there.
        #
        # "minimal" and "xhigh" are valid OpenRouter gateway effort values
        # (providers map them as needed, e.g. Gemini maps xhigh -> high), so
        # they are passed through unchanged.
        if reasoning_effort == "none":
            payload["reasoning"] = {"enabled": False}
        else:
            payload["reasoning"] = {"effort": reasoning_effort}

        # Add service tier if not default
        if service_tier != "default":
            payload["service_tier"] = service_tier

        # Inject structured output format. Two modes:
        # - "json_schema": strict JSON Schema (Structured Output). Only used
        #   when a non-empty, valid JSON string is provided.
        # - "json_object": plain JSON mode — the model is guaranteed to emit
        #   syntactically valid JSON, but without a schema constraint. The
        #   schema string is ignored in this mode.
        # An empty/whitespace schema in json_schema mode is explicitly removed
        # so OpenRouter does not receive a response_format.
        if json_schema is not None:
            json_schema = json_schema.strip()

        schema_key_order = []
        if response_format == "json_object":
            payload["response_format"] = {"type": "json_object"}
        elif json_schema:
            try:
                schema_dict = json.loads(json_schema)
                payload["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {
                        "name": "creator",
                        "strict": True,
                        "schema": schema_dict
                    }
                }
                # Preserve the schema's key order (properties/required) so the
                # processed output follows the intended index order instead of
                # alphabetical order.
                schema_key_order = list(schema_dict.get("properties", {}).keys())
                if not schema_key_order:
                    schema_key_order = schema_dict.get("required", [])
            except json.JSONDecodeError:
                print("Warning: Invalid JSON schema provided. Proceeding without structured output format.")
                schema_key_order = []
        else:
            # Ensure no stale response_format is carried over from a previous
            # call when the schema multiline is empty.
            payload.pop("response_format", None)
            schema_key_order = []

        # API Call
        # Use a Session with Connection: close to avoid keep-alive resets
        # (ConnectionResetError 10054) which OpenRouter sometimes triggers.
        # The request is streamed so the read timeout applies per-chunk (see
        # _post_streaming), and transient stalls are retried with exponential
        # backoff instead of hanging for the full timeout.
        try:
            result_json = None
            with requests.Session() as session:
                session.headers.update({"Connection": "close"})
                for attempt in range(MAX_RETRIES + 1):
                    try:
                        result_json = _post_streaming_with_cancel(
                            session,
                            "https://openrouter.ai/api/v1/chat/completions",
                            headers,
                            payload,
                        )
                        break
                    except (requests.exceptions.Timeout,
                            requests.exceptions.ConnectionError) as e:
                        if attempt < MAX_RETRIES:
                            delay = RETRY_BACKOFF * (2 ** attempt)
                            print(f"Warning: request failed ({e}). Retrying "
                                  f"in {delay:.0f}s "
                                  f"(attempt {attempt + 1}/{MAX_RETRIES})...")
                            _interruptible_sleep(delay)
                            continue
                        raise
            
            # Safely grab the response content and reasoning text.
            # OpenRouter exposes reasoning under message.reasoning (and some
            # providers use reasoning_content), so check both.
            message = result_json['choices'][0]['message']
            raw_output = message.get('content', '')
            reasoning = message.get('reasoning') or message.get('reasoning_content') or ''
            
            # Post-Process output mapping EXACTLY to your script.js logic
            # "Just join all string values (simplest, alphabetical order)"
            try:
                parsed_response = json.loads(raw_output)
                
                # Filter for strings; order by the schema's key order
                # (index order), unknown keys appended alphabetically at the end.
                string_keys = [k for k in parsed_response if isinstance(parsed_response[k], str)]
                ordered = [k for k in schema_key_order if k in string_keys]
                ordered += sorted(k for k in string_keys if k not in schema_key_order)
                
                # map and join with '\n'
                processed_output = "\n".join(parsed_response[k] for k in ordered)
            except Exception as e:
                # Fallback if raw text wasn't valid JSON (for instance, if model drops formatting)
                processed_output = f"[Not a valid JSON for processing] {raw_output}"

            return (raw_output, processed_output, reasoning)

        except requests.exceptions.RequestException as e:
            error_msg = f"API Request failed: {str(e)}"
            resp = getattr(e, "response", None)
            if resp is not None:
                error_msg += f"\nResponse: {resp.text}"
            return (error_msg, "Error Processing Output", "")


class OpenRouterStructuredOutputBatch:
    """Batch version of OpenRouterStructuredOutput.

    Runs the same request 4 times, each with a different seed derived from the
    base seed (seed, seed+1, seed+2, seed+3), and returns the results as
    ComfyUI lists (OUTPUT_IS_LIST).
    """

    BATCH_SIZE = 4

    def __init__(self):
        self._single = OpenRouterStructuredOutput()

    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "system_prompt": ("STRING", {"default": DEFAULT_SYSTEM_PROMPT, "multiline": True, "forceInput": True}),
                "user_prompt": ("STRING", {"default": "", "multiline": True, "forceInput": True}),
                "api_key": ("STRING", {"default": "sk-or-v1-...", "multiline": False}),
                "model": ("STRING", {"default": "google/gemini-3-flash-preview"}),
                "temperature": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.01}),
                "top_p": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.01}),
                "frequency_penalty": ("FLOAT", {"default": 0.0, "min": -2.0, "max": 2.0, "step": 0.01}),
                "presence_penalty": ("FLOAT", {"default": 0.0, "min": -2.0, "max": 2.0, "step": 0.01}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff}),
                "reasoning_effort": (["none", "minimal", "low", "medium", "high", "xhigh"], {"default": "none"}),
                "service_tier": (["default", "flex", "priority"], {"default": "default"}),
            },
            "optional": {
                "image": ("IMAGE",),
                "video": ("VIDEO",),
                "json_schema": ("STRING", {"default": json.dumps(DEFAULT_SCHEMA, indent=2), "multiline": True}),
                "response_format": (["json_schema", "json_object"], {"default": "json_schema"}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("raw_outputs", "processed_outputs", "reasonings")
    FUNCTION = "generate_batch"
    CATEGORY = "API/OpenRouter"
    OUTPUT_IS_LIST = (True, True, True)

    def generate_batch(self, user_prompt, system_prompt, api_key, model, temperature, top_p, frequency_penalty, presence_penalty, seed, reasoning_effort, service_tier, image=None, video=None, json_schema=None, response_format="json_schema"):
        # Run all 4 requests concurrently, each with a different seed.
        seeds = [(seed + i) & 0xffffffffffffffff for i in range(self.BATCH_SIZE)]

        with ThreadPoolExecutor(max_workers=self.BATCH_SIZE) as executor:
            futures = [
                executor.submit(
                    self._single.generate,
                    user_prompt=user_prompt,
                    system_prompt=system_prompt,
                    api_key=api_key,
                    model=model,
                    temperature=temperature,
                    top_p=top_p,
                    frequency_penalty=frequency_penalty,
                    presence_penalty=presence_penalty,
                    seed=batch_seed,
                    reasoning_effort=reasoning_effort,
                    service_tier=service_tier,
                    image=image,
                    video=video,
                    json_schema=json_schema,
                    response_format=response_format,
                )
                for batch_seed in seeds
            ]
            results = [future.result() for future in futures]

        raw_outputs = [raw for raw, _, _ in results]
        processed_outputs = [processed for _, processed, _ in results]
        reasonings = [reasoning for _, _, reasoning in results]

        return (raw_outputs, processed_outputs, reasonings)


class OpenRouterStructuredOutputMultiTurn:
    """Multi-turn version of OpenRouterStructuredOutput.

    Adds optional prior conversation turns (assistant_1, user_2, assistant_2,
    user_3, assistant_3, user_4) that are inserted before the final user
    message, enabling few-shot / multi-turn prompting. Empty inputs are
    skipped, so any subset of turns can be used.

    Assistant prefill: if the last non-empty turn is an assistant message
    (i.e. the conversation does not end on a user turn), that assistant
    message is used as an OpenRouter assistant prefill instead — it is
    appended AFTER the final user message so the model continues from it.
    """

    def __init__(self):
        self._single = OpenRouterStructuredOutput()

    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "system_prompt": ("STRING", {"default": DEFAULT_SYSTEM_PROMPT, "multiline": True, "forceInput": True}),
                "user_prompt": ("STRING", {"default": "", "multiline": True, "forceInput": True}),
                "api_key": ("STRING", {"default": "sk-or-v1-...", "multiline": False}),
                "model": ("STRING", {"default": "google/gemini-3-flash-preview"}),
                "temperature": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.01}),
                "top_p": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.01}),
                "frequency_penalty": ("FLOAT", {"default": 0.0, "min": -2.0, "max": 2.0, "step": 0.01}),
                "presence_penalty": ("FLOAT", {"default": 0.0, "min": -2.0, "max": 2.0, "step": 0.01}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff}),
                "reasoning_effort": (["none", "minimal", "low", "medium", "high", "xhigh"], {"default": "none"}),
                "service_tier": (["default", "flex", "priority"], {"default": "default"}),
            },
            "optional": {
                "image": ("IMAGE",),
                "video": ("VIDEO",),
                "json_schema": ("STRING", {"default": json.dumps(DEFAULT_SCHEMA, indent=2), "multiline": True}),
                "assistant_1": ("STRING", {"default": "", "multiline": True, "forceInput": True}),
                "user_2": ("STRING", {"default": "", "multiline": True, "forceInput": True}),
                "assistant_2": ("STRING", {"default": "", "multiline": True, "forceInput": True}),
                "user_3": ("STRING", {"default": "", "multiline": True, "forceInput": True}),
                "assistant_3": ("STRING", {"default": "", "multiline": True, "forceInput": True}),
                "user_4": ("STRING", {"default": "", "multiline": True, "forceInput": True}),
                "response_format": (["json_schema", "json_object"], {"default": "json_schema"}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("raw_output", "processed_output", "reasoning")
    FUNCTION = "generate_multi_turn"
    CATEGORY = "API/OpenRouter"

    def generate_multi_turn(self, user_prompt, system_prompt, api_key, model, temperature, top_p, frequency_penalty, presence_penalty, seed, reasoning_effort, service_tier, image=None, video=None, json_schema=None, response_format="json_schema",
                            assistant_1="", user_2="", assistant_2="", user_3="", assistant_3="", user_4=""):
        extra_turns = [
            ("assistant", assistant_1),
            ("user", user_2),
            ("assistant", assistant_2),
            ("user", user_3),
            ("assistant", assistant_3),
            ("user", user_4),
        ]

        # If the last non-empty turn is an assistant message, use it as an
        # assistant prefill (appended after the final user message) instead
        # of a prior conversation turn, per OpenRouter's Assistant prefill.
        assistant_prefill = None
        for i in range(len(extra_turns) - 1, -1, -1):
            role, text = extra_turns[i]
            if text is not None and str(text).strip():
                if role == "assistant":
                    assistant_prefill = str(text)
                    extra_turns = extra_turns[:i]
                break

        return self._single.generate(
            user_prompt=user_prompt,
            system_prompt=system_prompt,
            api_key=api_key,
            model=model,
            temperature=temperature,
            top_p=top_p,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            seed=seed,
            reasoning_effort=reasoning_effort,
            service_tier=service_tier,
            image=image,
            video=video,
            json_schema=json_schema,
            response_format=response_format,
            extra_turns=extra_turns,
            assistant_prefill=assistant_prefill,
        )


DEFAULT_DECISION_QUESTIONS = {
    "matches": {
        "type": "noul",
        "instructions": "The content matches the description in the text."
    }
}


class OpenRouterDecisions:
    """Asks an OpenRouter Decisions model typed questions about the input.

    Decisions models never write prose: each entry in `questions` gets a typed
    answer (`noul`, `choice`, `score`, `box`) instead. The model comes from
    output_modalities=decisions -- e.g. cloudflare/clef-flash,
    inception/mercury-decide or ~typesafe/jev-latest.

    `state_text` is the content being judged. Connected image, video and audio
    inputs are appended to it as media parts; text stays plain strings, as the
    Decisions API expects.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "api_key": ("STRING", {"default": "sk-or-v1-...", "multiline": False}),
                "model": ("STRING", {"default": "cloudflare/clef-flash"}),
                "state_text": ("STRING", {"default": "", "multiline": True}),
                "questions": ("STRING", {"default": json.dumps(DEFAULT_DECISION_QUESTIONS, indent=2), "multiline": True}),
            },
            "optional": {
                "image": ("IMAGE",),
                "video": ("VIDEO",),
                "audio": ("AUDIO",),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("raw_output", "answers", "summary")
    FUNCTION = "decide"
    CATEGORY = "API/OpenRouter"
    DESCRIPTION = ("Typed questions (noul / choice / score / box) answered by an OpenRouter Decisions model. "
                   "Questions are a JSON object of question_id -> question definition.")

    def decide(self, api_key, model, state_text, questions, image=None, video=None, audio=None):
        if not api_key or api_key == "sk-or-v1-...":
            return ("Error: Valid API Key is required.", "", "")

        if not questions or not questions.strip():
            return ("Error: questions is empty.", "", "")
        try:
            questions_obj = json.loads(questions)
        except json.JSONDecodeError as e:
            return (f"Error: questions is not valid JSON: {e}", "", "")
        if not isinstance(questions_obj, dict) or not questions_obj:
            return ("Error: questions must be a non-empty JSON object of question_id -> question.", "", "")

        # `state` holds the content the questions are about: plain strings for
        # text (not {type: text} parts) followed by media parts.
        state = []
        if state_text and state_text.strip():
            state.append(state_text)
        if image is not None:
            state.extend(_image_content_parts(image))
        if video is not None:
            try:
                video_uri = _video_to_data_uri(video)
            except Exception as e:
                return (f"Error: Unable to encode video input: {e}", "", "")
            if video_uri:
                state.append({"type": "video_url", "video_url": {"url": video_uri}})
        if audio is not None:
            try:
                audio_part = _audio_content_part(audio)
            except Exception as e:
                return (f"Error: Unable to encode audio input: {e}", "", "")
            if audio_part:
                state.append(audio_part)
        if not state:
            return ("Error: provide state_text, an image, a video, or audio to decide on.", "", "")

        payload = {
            "model": model.strip(),
            "state": state,
            "questions": questions_obj,
        }

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        try:
            _check_interrupted()
            with requests.Session() as session:
                session.headers.update({"Connection": "close"})
                response = session.post(
                    "https://openrouter.ai/api/alpha/decisions",
                    headers=headers,
                    json=payload,
                    timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
                )
                response.raise_for_status()
                result = response.json()
        except requests.exceptions.RequestException as e:
            error_msg = f"API Request failed: {str(e)}"
            resp = getattr(e, "response", None)
            if resp is not None:
                error_msg += f"\nResponse: {resp.text}"
            return (error_msg, "", "")

        answers_obj = result.get("answers") if isinstance(result, dict) else None
        if not isinstance(answers_obj, dict):
            answers_obj = {}
        raw_output = json.dumps(result, indent=2, ensure_ascii=False)
        answers = json.dumps(answers_obj, indent=2, ensure_ascii=False)
        summary = "\n".join(
            _format_decision_answer(question_id, answer)
            for question_id, answer in answers_obj.items()
        )
        return (raw_output, answers, summary)


class OpenRouterNoulToBool:
    """Turns a noul answer into a plain boolean.

    A noul is a scored yes/no -- {"type": "noul", "noul": 0.86}. This node
    reads that probability from the answers JSON and reports True once it
    reaches `threshold`. A blank `question` uses the first noul in the answers.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "answers": ("STRING", {"default": "", "multiline": True, "forceInput": True}),
                "question": ("STRING", {"default": ""}),
                "threshold": ("FLOAT", {"default": 0.5, "min": 0.0, "max": 1.0, "step": 0.01}),
            }
        }

    RETURN_TYPES = ("BOOLEAN",)
    RETURN_NAMES = ("value",)
    FUNCTION = "convert"
    CATEGORY = "API/OpenRouter"
    DESCRIPTION = ("Reads a noul probability from a Decisions answers JSON and outputs True at or above the "
                   "threshold. A blank `question` takes the first noul.")

    def convert(self, answers, question="", threshold=0.5):
        if not answers or not answers.strip():
            print("OpenRouter Noul to Boolean: no answers input.")
            return (False,)
        try:
            data = json.loads(answers)
        except json.JSONDecodeError as e:
            print(f"OpenRouter Noul to Boolean: answers is not valid JSON ({e}).")
            return (False,)

        # Accept either the full Decisions response or just its answers object.
        if isinstance(data, dict) and isinstance(data.get("answers"), dict):
            data = data["answers"]
        if not isinstance(data, dict):
            print("OpenRouter Noul to Boolean: expected a JSON object of answers.")
            return (False,)

        name = (question or "").strip()
        if name:
            if name not in data:
                print(f"OpenRouter Noul to Boolean: question '{name}' not found.")
                return (False,)
            return (_answer_to_bool(data[name], threshold),)

        for answer in data.values():
            if isinstance(answer, dict) and "noul" in answer:
                return (_answer_to_bool(answer, threshold),)
        # No noul in the payload: use the first answer of any type.
        for answer in data.values():
            return (_answer_to_bool(answer, threshold),)
        print("OpenRouter Noul to Boolean: answers object is empty.")
        return (False,)


# Mappings required by ComfyUI
NODE_CLASS_MAPPINGS = {
    "OpenRouterStructuredOutput": OpenRouterStructuredOutput,
    "OpenRouterStructuredOutputBatch": OpenRouterStructuredOutputBatch,
    "OpenRouterStructuredOutputMultiTurn": OpenRouterStructuredOutputMultiTurn,
    "OpenRouterDecisions": OpenRouterDecisions,
    "OpenRouterNoulToBool": OpenRouterNoulToBool,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "OpenRouterStructuredOutput": "OpenRouter Structured JSON Output",
    "OpenRouterStructuredOutputBatch": "OpenRouter Structured JSON Output (Batch x4)",
    "OpenRouterStructuredOutputMultiTurn": "OpenRouter Structured JSON Output (Multi-Turn)",
    "OpenRouterDecisions": "OpenRouter Decisions",
    "OpenRouterNoulToBool": "OpenRouter Noul to Boolean",
}